package com.calculator;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CalculatorServlet")
public class CalculatorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String displayValue = request.getParameter("display");
        double result = 0;
        String error = null;

        // Validate input length
        if (displayValue.length() > 100) {
            error = "Input exceeds 100 characters!";
        }

        // Check for consecutive operators or invalid input
        if (displayValue.matches(".*[+\\-*/]{2,}.*")) {
            error = "Invalid input! Consecutive operators are not allowed.";
        }

        // If there's no error, proceed with the calculation
        if (error == null) {
            try {
                // Check if the input is just a number
                if (displayValue.matches("[0-9]+")) {
                    result = Double.parseDouble(displayValue);
                } else {
                    // Otherwise, perform the operation
                    String[] tokens = displayValue.split("([+\\-*/])");
                    if (tokens.length < 2) {
                        error = "Invalid input! Please provide two operands.";
                    } else {
                        double firstNumber = Double.parseDouble(tokens[0]);
                        double secondNumber = Double.parseDouble(tokens[1]);
                        char operator = displayValue.charAt(tokens[0].length());

                        switch (operator) {
                            case '+': result = firstNumber + secondNumber; break;
                            case '-': result = firstNumber - secondNumber; break;
                            case '*': result = firstNumber * secondNumber; break;
                            case '/': 
                                if (secondNumber != 0) {
                                    result = firstNumber / secondNumber;
                                } else {
                                    error = "Cannot divide by zero!";
                                }
                                break;
                            default:
                                error = "Invalid operator!";
                                break;
                        }
                    }
                }
            } catch (Exception e) {
                error = "Invalid input!";
            }
        }

        // Set attributes to be used in the JSP page
        if (error != null) {
            request.setAttribute("error", error);
            request.setAttribute("display", displayValue);
        } else {
            request.setAttribute("result", result);
            request.setAttribute("display", String.valueOf(result));
        }

        // Forward to the JSP page
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}
